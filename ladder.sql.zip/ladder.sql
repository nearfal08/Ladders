--
-- Database: `ladder`
--

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lol_historical_standings`
--

CREATE TABLE `lol_historical_standings` (
  `id` int(11) NOT NULL,
  `rank` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `wins` int(11) DEFAULT NULL,
  `losses` int(11) DEFAULT NULL,
  `ranking_day` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lol_live_standings`
--

CREATE TABLE `lol_live_standings` (
  `id` int(10) UNSIGNED NOT NULL,
  `rank` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `wins` int(11) DEFAULT NULL,
  `losses` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lol_live_standings`
--

INSERT INTO `lol_live_standings` (`id`, `rank`, `name`, `points`, `level`, `wins`, `losses`) VALUES
(201, 1, 'Grig1', 1255, NULL, 652, 564),
(202, 2, 'MLGB BIade', 1185, NULL, 292, 204),
(203, 3, 'elise player', 1182, NULL, 667, 568),
(204, 4, 'Isaac Marconis', 1172, NULL, 632, 525),
(205, 5, 'Johnsun', 1163, NULL, 448, 352),
(206, 6, 'Rallemus', 1139, NULL, 395, 309),
(207, 7, 'Saaantorin', 1126, NULL, 460, 368),
(208, 8, 'Vïper', 1101, NULL, 591, 499),
(209, 9, 'MLGB B?ade', 1100, NULL, 305, 200),
(210, 10, 'insanityxxx', 1074, NULL, 1707, 1632),
(211, 11, 'blaberfish2', 1071, NULL, 760, 682),
(212, 12, 'Ablazeolive', 1021, NULL, 424, 352),
(213, 13, 'Imaqtpie', 988, NULL, 472, 401),
(214, 14, 'Rikara', 969, NULL, 418, 333),
(215, 15, 'fulano', 952, NULL, 216, 144),
(216, 16, 'C9 Sneaky', 900, NULL, 495, 416),
(217, 17, 'dawolfsfang', 877, NULL, 535, 466),
(218, 18, 'TRI POLOSKI', 859, NULL, 385, 316),
(219, 19, 'loi?', 853, NULL, 185, 96),
(220, 20, 'Shøryu', 848, NULL, 449, 376),
(221, 21, 'Pobelter', 846, NULL, 741, 671),
(222, 22, 'Soligo', 846, NULL, 554, 477),
(223, 23, 'The Tank Man', 833, NULL, 1199, 1127),
(224, 24, 'Keegun', 833, NULL, 348, 284),
(225, 25, 'Cris', 829, NULL, 882, 819),
(226, 26, 'Doublelift', 825, NULL, 558, 489),
(227, 27, 'ybooks', 816, NULL, 425, 355),
(228, 28, 'UKP Ñeøø', 803, NULL, 540, 473),
(229, 29, 'Teesum', 799, NULL, 671, 606),
(230, 30, 'Liquid fabbbyyy', 797, NULL, 588, 528),
(231, 31, 'PrismaI', 795, NULL, 710, 643),
(232, 32, 'Fox Fen1X', 782, NULL, 117, 60),
(233, 33, 'Faze Palafox', 779, NULL, 686, 620),
(234, 34, 'Pants are Dragon', 773, NULL, 802, 738),
(235, 35, 'Vulcan1', 769, NULL, 1028, 972),
(236, 36, 'salsasister17', 762, NULL, 520, 444),
(237, 37, 'GangstahSwerve', 757, NULL, 469, 414),
(238, 38, 'Dhokla', 752, NULL, 800, 742),
(239, 39, 'XueGao', 751, NULL, 343, 274),
(240, 40, 'RAHÜLK', 750, NULL, 723, 596),
(241, 41, 'wiggily ad', 740, NULL, 192, 108),
(242, 42, 'lozt', 726, NULL, 123, 73),
(243, 43, 'Gaow Gaiy', 726, NULL, 641, 563),
(244, 44, 'Mirolla', 725, NULL, 216, 142),
(245, 45, 'Apollo Price', 721, NULL, 543, 483),
(246, 46, 'Erry', 719, NULL, 804, 739),
(247, 47, 'Jue VioIe Grace', 718, NULL, 545, 487),
(248, 48, 'lron Pyrite', 709, NULL, 389, 323),
(249, 49, 'TakatsukiSen', 707, NULL, 244, 156),
(250, 50, 'Hakuho', 704, NULL, 272, 214),
(251, 51, 'KeegunS', 702, NULL, 249, 189),
(252, 52, 'Teamfighting', 700, NULL, 320, 232),
(253, 53, 'Im Fuming', 699, NULL, 413, 293),
(254, 54, 'Julien', 682, NULL, 1054, 993),
(255, 55, 'Manifest', 680, NULL, 245, 184),
(256, 56, 'Acoldblazeolive', 679, NULL, 288, 233),
(257, 57, 'Línsanity', 676, NULL, 229, 170),
(258, 58, 'Cody Sun', 657, NULL, 715, 656),
(259, 59, 'Ash?', 655, NULL, 327, 226),
(260, 60, 'Linsaníty', 651, NULL, 405, 348),
(261, 61, 'Tony Top 2', 651, NULL, 411, 343),
(262, 62, 'Pekin Woof', 651, NULL, 436, 381),
(263, 63, 'CHIEF KEITH', 649, NULL, 319, 245),
(264, 64, 'Tuesdayy', 646, NULL, 860, 805),
(265, 65, 'mvsh', 639, NULL, 317, 262),
(266, 66, '5tunt', 638, NULL, 385, 313),
(267, 67, 'LL Stylish', 637, NULL, 1092, 1056),
(268, 68, 'Jowey', 627, NULL, 571, 512),
(269, 69, 'Spica 16', 623, NULL, 309, 244),
(270, 70, 'Ahigholive', 622, NULL, 189, 106),
(271, 71, 'Wiggily', 619, NULL, 681, 635),
(272, 72, 'Shiphtur', 618, NULL, 1342, 1295),
(273, 73, 'Ivan Pavlov', 616, NULL, 516, 458),
(274, 74, 'joong ki song', 611, NULL, 316, 250),
(275, 75, 'Value', 610, NULL, 246, 189),
(276, 76, '5word', 609, NULL, 333, 273),
(277, 77, 'bobqin1', 604, NULL, 276, 184),
(278, 78, 'goldenglue', 603, NULL, 518, 462),
(279, 79, 'HairySixPack', 599, NULL, 264, 160),
(280, 80, 'LittleFrosty', 598, NULL, 244, 178),
(281, 81, 'Born For It', 594, NULL, 909, 854),
(282, 82, 'Scrandor', 591, NULL, 611, 559),
(283, 83, 'MikeYeunglol', 583, NULL, 248, 173),
(284, 84, 'Rohammers', 580, NULL, 969, 922),
(285, 85, 'MLGB Clown', 580, NULL, 288, 216),
(286, 86, 'CLG Reign0ver', 577, NULL, 254, 170),
(287, 87, 'Lethal Zedster', 570, NULL, 276, 210),
(288, 88, 'FallenBandit', 568, NULL, 637, 585),
(289, 89, 'Meta', 568, NULL, 259, 175),
(290, 90, 'OmarGod', 567, NULL, 343, 284),
(291, 91, 'crow4', 566, NULL, 469, 418),
(292, 92, 'wiggily top', 565, NULL, 1265, 1207),
(293, 93, 'NintendudeX', 562, NULL, 454, 395),
(294, 94, 'Warum denkst du', 561, NULL, 610, 558),
(295, 95, '5148', 560, NULL, 213, 99),
(296, 96, 'undr ctrl', 560, NULL, 411, 357),
(297, 97, 'Coach is Beyond', 557, NULL, 441, 390),
(298, 98, 'OddOJ', 552, NULL, 1146, 1092),
(299, 99, 'Peridot', 551, NULL, 493, 431),
(300, 100, 'self awakening', 551, NULL, 647, 597),
(301, 101, 'GGS Matt', 551, NULL, 606, 540),
(302, 102, 'NoahMost', 550, NULL, 384, 326),
(303, 103, 'Pyrites', 550, NULL, 400, 350),
(304, 104, 'Flareszt', 549, NULL, 544, 493),
(305, 105, 'Rathma', 547, NULL, 519, 455),
(306, 106, 'GGS Mata', 546, NULL, 205, 150),
(307, 107, 'Weeknd', 545, NULL, 1074, 1030),
(308, 108, 'Irelia Carries U', 541, NULL, 457, 397),
(309, 109, 'Piggy Kitten', 541, NULL, 724, 675),
(310, 110, 'deftIy', 537, NULL, 311, 253),
(311, 111, 'dawolfsclaw', 537, NULL, 413, 361),
(312, 112, 'Allorim', 537, NULL, 574, 530),
(313, 113, 'Phaxen', 537, NULL, 232, 177),
(314, 114, 'nihonjin', 535, NULL, 259, 177),
(315, 115, 'tummysalami', 535, NULL, 265, 193),
(316, 116, 'i need some suga', 533, NULL, 233, 141),
(317, 117, 'Zeyzal', 532, NULL, 304, 245),
(318, 118, 'Lebron Jamés ', 530, NULL, 491, 445),
(319, 119, 'FaZe Trance', 528, NULL, 533, 471),
(320, 120, 'Kingslayer Sheep', 528, NULL, 621, 579),
(321, 121, 'Ssita', 527, NULL, 265, 215),
(322, 122, 'CookiesforSanta', 527, NULL, 207, 145),
(323, 123, 'Game1234', 526, NULL, 560, 463),
(324, 124, 'salt on bench', 526, NULL, 339, 285),
(325, 125, 'import top', 524, NULL, 168, 126),
(326, 126, 'Cotosaurio', 520, NULL, 1198, 1130),
(327, 127, 'Day after Day', 519, NULL, 699, 647),
(328, 128, 'Tmoney', 517, NULL, 603, 542),
(329, 129, 'Brother Dyrus', 513, NULL, 493, 447),
(330, 130, 'Jurassiq', 512, NULL, 321, 255),
(331, 131, 'SandPaperX', 511, NULL, 661, 613),
(332, 132, 'Nightblue3', 509, NULL, 777, 729),
(333, 133, 'bobqinXD', 509, NULL, 259, 201),
(334, 134, 'Event', 508, NULL, 320, 262),
(335, 135, 'Bhaalspawn', 506, NULL, 498, 428),
(336, 136, 'Licorice', 506, NULL, 398, 338),
(337, 137, 'fwii', 502, NULL, 363, 310),
(338, 138, 'Falcon God', 502, NULL, 403, 354),
(339, 139, 'Baekk', 499, NULL, 238, 166),
(340, 140, 'Nugeek', 497, NULL, 159, 83),
(341, 141, 'Andybendy', 495, NULL, 923, 878),
(342, 142, 'yeedam', 493, NULL, 172, 123),
(343, 143, 'The Real Notes', 492, NULL, 174, 105),
(344, 144, 'LF love', 492, NULL, 353, 294),
(345, 145, 'tebomb2', 491, NULL, 263, 195),
(346, 146, ' Sudzzi', 490, NULL, 668, 622),
(347, 147, 'RobbyBob', 488, NULL, 234, 182),
(348, 148, 'FaZe Càm', 488, NULL, 459, 405),
(349, 149, 'Autolycus1', 488, NULL, 481, 420),
(350, 150, 'Jayms', 487, NULL, 266, 217),
(351, 151, 'Chimonaa1', 486, NULL, 372, 316),
(352, 152, 'KiNG Nidhogg', 486, NULL, 777, 720),
(353, 153, 'Archhangel', 485, NULL, 481, 419),
(354, 154, 'humans can fly', 484, NULL, 138, 85),
(355, 155, 'JG King8', 484, NULL, 502, 439),
(356, 156, 'CLA Tuesday', 482, NULL, 357, 291),
(357, 157, 'MlST LFT', 482, NULL, 342, 284),
(358, 158, 'MLGB Top', 482, NULL, 276, 150),
(359, 159, 'Hungry Like', 481, NULL, 1447, 1396),
(360, 160, 'i need smth fake', 481, NULL, 124, 83),
(361, 161, 'MLGB TailsJJ', 480, NULL, 302, 241),
(362, 162, 'EU Import Jungle', 479, NULL, 311, 194),
(363, 163, 'fwii Tryn', 478, NULL, 175, 84),
(364, 164, 'jeffrey0529', 478, NULL, 410, 348),
(365, 165, 'MooseHater', 477, NULL, 467, 413),
(366, 166, 'rovex', 477, NULL, 817, 763),
(367, 167, 'Super Metroid', 477, NULL, 286, 226),
(368, 168, 'Terina', 477, NULL, 321, 264),
(369, 169, 'Shout', 476, NULL, 650, 604),
(370, 170, 'freelancer', 476, NULL, 422, 380),
(371, 171, 'Tawnington', 475, NULL, 216, 156),
(372, 172, 'Flaresz', 474, NULL, 351, 289),
(373, 173, 'Tony Top 3', 474, NULL, 558, 491),
(374, 174, 'chowdong', 474, NULL, 335, 288),
(375, 175, 'Hyami', 473, NULL, 361, 292),
(376, 176, 'Lyo', 473, NULL, 239, 179),
(377, 177, 'CC Dean', 472, NULL, 313, 253),
(378, 178, 'Kazahana', 472, NULL, 386, 338),
(379, 179, 'Chasing Summer', 472, NULL, 567, 514),
(380, 180, 'KatEvolved1', 471, NULL, 248, 178),
(381, 181, 'LucLogic', 471, NULL, 387, 324),
(382, 182, 'UUmeiDe55Kai', 471, NULL, 523, 422),
(383, 183, 'Takashí', 471, NULL, 454, 374),
(384, 184, 'Pretty Raheem', 469, NULL, 191, 138),
(385, 185, 'Eitori', 469, NULL, 407, 354),
(386, 186, 'YIlIlIlIlI', 469, NULL, 315, 262),
(387, 187, 'Dylaran', 468, NULL, 477, 397),
(388, 188, 'OMG CIoud', 468, NULL, 119, 47),
(389, 189, 'MotionPlan598', 468, NULL, 134, 58),
(390, 190, 'KT Khan', 468, NULL, 133, 69),
(391, 191, 'TFW SaoZi', 468, NULL, 344, 281),
(392, 192, 'FoTheWin', 467, NULL, 219, 162),
(393, 193, 'TheYeungle', 466, NULL, 107, 58),
(394, 194, '5fire', 466, NULL, 336, 282),
(395, 195, 'bobqinX', 464, NULL, 462, 398),
(396, 196, 'LHHS', 463, NULL, 158, 102),
(397, 197, 'sun x', 463, NULL, 155, 82),
(398, 198, 'Duo Abuse', 463, NULL, 101, 41),
(399, 199, 'Morïarty', 462, NULL, 470, 422),
(400, 200, 'Fanatiik', 461, NULL, 976, 932);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lol_historical_standings`
--
ALTER TABLE `lol_historical_standings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lol_live_standings`
--
ALTER TABLE `lol_live_standings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lol_historical_standings`
--
ALTER TABLE `lol_historical_standings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `lol_live_standings`
--
ALTER TABLE `lol_live_standings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=401;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
